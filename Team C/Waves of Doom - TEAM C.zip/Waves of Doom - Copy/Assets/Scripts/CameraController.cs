﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour 
{
	//Get the transform of "the player"
	public Transform player;
	//Creating a new Vector3
	Vector3 offset;

	// Use this for initialization
	void Start () 
	{
		//Finds the players transform component
		player = GameObject.Find ("Player").GetComponent<Transform> ();
		//Creates an offset placement from the cameras transform to the players transform
		offset = transform.position - player.transform.position;
	}

	void LateUpdate () 
	{
		//Moves the cameras position to the new offsetted position
		transform.position = player.transform.position + offset;
		//Limits the boundries of the cameras movements to be within the game
		transform.position = new Vector3 (Mathf.Clamp (transform.position.x, -7.6f, 7.6f), Mathf.Clamp (transform.position.y, 0.6f, 3.4f), Mathf.Clamp (transform.position.z, -10, -10));
	}
}
