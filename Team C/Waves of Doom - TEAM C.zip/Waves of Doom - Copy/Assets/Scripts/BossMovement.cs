﻿using UnityEngine;
using System.Collections;


public class BossMovement: MonoBehaviour 
{
	//Gets the rigidbody of the object this script is attached to
	public Rigidbody2D rb2d;
	//Get the transform of the target "the player"
	public Transform target;
	//Make a reference to the Boss GameObject
	public GameObject Boss;
	//A variable to allow the game to know which way the boss is facing
	bool facingRIGHT = true;
	//Gets an animator to use for animations
	private Animator animator;

	void Start()
	{
		//Gets an animator component
		animator = GetComponent<Animator> ();
		//Gets rigidbody component
		rb2d = GetComponent<Rigidbody2D> ();
		//Repetitively calls the Attack ever 3 seconds
		InvokeRepeating ("bossBounceAttack", 1f, 3f);
	}

	void FixedUpdate()
	{
		//Detects if the player is on the left or right side and flips accordingly
		if (transform.position.x > target.position.x && facingRIGHT) 
		{
			flip ();
			facingRIGHT = false; 
		} 
		else if (transform.position.x < target.position.x && !facingRIGHT)
		{
			flip ();
			facingRIGHT = true;
		}
	}

	void bossBounceAttack()
	{
		//If the player is on the left or right side the boss will jump in the direction accordingly
		if(transform.position.x > target.position.x) 
		{
			animator.SetTrigger ("Jumping");
			rb2d.AddForce ((Vector2.up) * 15f, ForceMode2D.Impulse);
			rb2d.AddForce ((Vector2.left) * 4f, ForceMode2D.Impulse);
		}

		else if (transform.position.x < target.position.x) 
		{
			animator.SetTrigger ("Jumping");
			rb2d.AddForce ((Vector2.up) * 15f,ForceMode2D.Impulse);
			rb2d.AddForce ((Vector2.right) * 4f, ForceMode2D.Impulse);
		}
	}

	void flip()
	{
		//Flips the X scaling from negative to positive to resemble the "left or right" direction
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

}