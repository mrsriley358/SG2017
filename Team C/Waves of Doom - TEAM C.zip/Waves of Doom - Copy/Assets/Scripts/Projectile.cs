﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {
	//Floats to determine the damge and speed of the fireball
	public float projectileSpeed;
	public float enemyDamage = 10f;
	//A reference to the players location
	Transform Player;

	private bool hasCollide = false;



	void Start () 
	{
		Player = GameObject.FindGameObjectWithTag ("Player").transform;

	}
	

	void Update () 
	{
		//This allows the fireball to move constantly in the players direction and if it has not collided within X seconds of spawning it destroys itself
		hasCollide = false;
		float dis = projectileSpeed * Time.deltaTime;
		transform.position = Vector2.MoveTowards(transform.position, Player.position, dis);
		GameObject.Destroy (gameObject, 1);
	}


	void OnTriggerEnter2D(Collider2D other)
	{
		//Deals damage to the player or it "Subtracts health from player" causing damage
		if (other.gameObject.CompareTag ("Player") && hasCollide == false) 
		{
			hasCollide = true;
			GameObject.Find ("Player").GetComponent<PlayerController> ().knockbackCount = .2f;
			GameObject.Find("Player").GetComponent<PlayerHealth>().playerHealth -= enemyDamage;
			//This creates knockback on the player when it's attacked
			var player = other.GetComponent <PlayerController> ();
			player.knockbackCount = player.knockbackLength;

			if (other.transform.position.x < transform.position.x)
			{
				player.knockedFromRight = true;
			}

			else
			{
				player.knockedFromRight = false;
			}
		}
		//Destroys the fireball on collision with the player
		if (other.gameObject.CompareTag ("Player"))
			Destroy (gameObject);
	}




}
