﻿using UnityEngine;
using System.Collections;

public class HealthSize : MonoBehaviour 
{
	public RectTransform player;
	public float healthSize;


	// Use this for initialization
	void Start () 
	{
		healthSize = 0.019f;
	}
	
	// Update is called once per frame
	void Update () 
	{
		player.sizeDelta = new Vector2 (healthSize, 0.25f);
	}
}
