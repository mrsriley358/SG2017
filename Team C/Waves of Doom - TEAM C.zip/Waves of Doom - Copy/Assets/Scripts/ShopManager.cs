﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class ShopManager : MonoBehaviour 
{
	//Make references to the buttons ingame
	public Button AttackDMG;
	public Button HealthInc;
	public Button HealthPOTION;
	//Makes GameObjects references
	public GameObject panel;
	public GameObject exitPanel;
	public GameObject Player;
	public GameObject healthBar;
	//Make ints to hold various values
	int goldIncAtk;
	int goldIncHeal;
	int atkLimit;
	public int potionCounter;
	int AttackInc = 0;
	int healthIncrease = 0;
	//Make all the references to Texts
	public Text atkPrice;
	public Text healPrice;
	public Text curDamage;
	public Text curHealth;
	public Text curPotions;
	public Text potionCount;
	public Text Attack;
	public Text healthInc;
	public Text Heals;

	void Start() 
	{
		//Starts with the shop panel to be closed and your potions to be set to 0
		panel.SetActive (false);
		potionCounter = 0;
	}

	private void OnGUI() 
	{
		//When you press "G" it pauses the game and opens the shop panel
		if (Input.GetKeyDown ("g")) 
		{
			panel.SetActive (true);
			Pause ();
			Heals.text = " ";
			//If you have less than 3 potions you can buy more, and more, and more, and more, and more, and more, and more, and more, and more, and more.
			if (potionCounter <= 3)
				HealthPOTION.interactable = true;
		}
		//When you press "esc" it pauses the game and opens the exit panel
		else if (Input.GetKeyDown ("escape"))
		{
			exitPanel.SetActive (true);
			//Calls the method
			Pause ();
		}
	}
	//This is the Attack booster method to increase players damage after purchasing in the shop
	public void AttackUP()
	{
		if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold < 1 + goldIncAtk)
		{
			Attack.text = "Not Enough Money!";
		}

		else if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold >= 1 + goldIncAtk)
		{
			AttackInc += 5;
			GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerDamage += 2;
			GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold -= 1 + goldIncAtk;
			GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().SetScoreText ();

			goldIncAtk += 1;
			atkLimit++;
			atkPrice.text = ("Price: " + (1 + goldIncAtk) + " Gold");

			Attack.text = "Your damage has increased by 2!";
			curDamage.text = "Current Damage: " + (GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerDamage ).ToString();
		}

		if (atkLimit == 50) 
		{
			AttackDMG.interactable = false; 
			atkPrice.text = ("Price: NA");
			Attack.text = "";
		}
		SetPotionCount ();
	}
	//This booster method increases player health after purchasing in the shop
	public void Booster()
	{
		if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold < 5 + goldIncHeal)
		{
			healthInc.text = "Not Enough Money!";
		}

		else if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold >= 5 + goldIncHeal)
		{
			GameObject.Find ("Player").GetComponent<PlayerHealth> ().maxPlayerHealth += 20;
			GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerHealth += 20;
			healthIncrease++;

			curHealth.text = "Current Health: " + (GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerHealth ).ToString();
			//Sets the button to false so that you have a max health you can buy
			if (healthIncrease == 5)
				HealthInc.interactable = false;

			healthInc.text = "Your health has been increased by 20!";
			//Subtracts 5 gold and increaces itself each buy
			GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold -= 5 + goldIncHeal;
			GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().SetScoreText ();

			goldIncHeal += 5;

			if (healthIncrease <= 4)
				healPrice.text = ("Price: " + (5 + goldIncHeal) + " Gold");
			
			else 
			{
				healPrice.text = ("Price: NA");
				healthInc.text = "";
			}
		}
	}
	//This is the Attack booster method to increase players damage after purchasing in the shop
	public void Package()
	{ 
		if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold < 5)
			Heals.text = "Not Enough Money!";
		//If the player has more than 1 gold he can then purchase a potion
		else if (GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold >= 5)
		{
			//if the player has less than the max amout of potions he can then buy one
			if (potionCounter < 5) 
			{
				GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().gold -= 5;
				GameObject.Find ("Player").GetComponent<CollisionCollectiables> ().SetScoreText ();
				potionCounter++;
				Heals.text = "You Got A Potion!";
				HealthPOTION.interactable = true;

				curPotions.text = "Current Potions: " + potionCounter.ToString();
			} 

			else 
			{
				//if the player has too many potions the shop will display "Potions are full"
				Heals.text = "Potions Are Full!";
				HealthPOTION.interactable = false;
			}
		}
		SetPotionCount ();
	}

	public void Leave ()
	{
		//sets the shop panel to false
		panel.SetActive (false);
		//sets the time scale of the game back to normal for gameplay to resume
		Resume ();
	}

	public void SetPotionCount()
	{
		//Convert the counter value on collision to a value displayed ingame.
		potionCount.text = "" + potionCounter.ToString();
	}

	//after pausing the game it resumes the game
	public void No ()
	{
		exitPanel.SetActive (false);
		Resume ();
	}
	//stops the time ingame to "pause it"
	void Pause() 
	{
		Time.timeScale = 0;
	}
	//resumes the time ingame to "resume it"
	void Resume() 
	{
		Time.timeScale = 1;
	}
}
