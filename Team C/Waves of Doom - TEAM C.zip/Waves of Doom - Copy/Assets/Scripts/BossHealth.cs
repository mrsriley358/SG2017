﻿using UnityEngine;
using System.Collections;


public class BossHealth : MonoBehaviour 
{
	//Get the five objects for the health systems
	public GameObject Boss;
	public GameObject health;
	public GameObject dOneHealth, dTwoHealth, dThreeHealth;
	//get the current health from all the bosses health bars
	public float bossHealth, divisionOneHealth, divisionTwoHealth, divisionThreeHealth;
	//Set all the divisions max healths
	float maxBossHealth = 500f, maxdivisionOneHealth = 400f, maxdivisionTwoHealth = 300f, maxdivisionThreeHealth = 200f;
	//Boss damage
	public float bossDamage;
	//A bool to decide if something has collided with the boss
	private bool hasCollide = false;
	//Players sword collider
	private CircleCollider2D Sword;
	//Gets references to the division one instance of the boss and a coin
	public GameObject D1; 
	public GameObject Coin;
	//Bool to allow a coin to drop
	bool drop = true;

	void Start()
	{
		
	}
	// Update is called once per frame
	void Update () 
	{
		//Sets up all the health bars scalings
		float bossPercent = bossHealth / maxBossHealth;
		float boss1Percent = divisionOneHealth / maxdivisionOneHealth;
		float boss2Percent = divisionTwoHealth / maxdivisionTwoHealth;
		float boss3Percent = divisionThreeHealth / maxdivisionThreeHealth;

		//set the scale of the health bars to what cur_health is
		health.transform.localScale = new Vector2 (bossPercent, 1f);
		dOneHealth.transform.localScale = new Vector2 (boss1Percent, 1f);
		dTwoHealth.transform.localScale = new Vector2 (boss2Percent, 1f);
		dThreeHealth.transform.localScale = new Vector2 (boss3Percent, 1f);

		//Sets to false constanly so damage only occurs once
		hasCollide = false;
		//Gets the componet of the sword object tagged "Sword"
		Sword = GameObject.Find ("Sword").GetComponent<CircleCollider2D> ();
		//Finds if the boss health is 0, then it drops a coin
		if (bossHealth <= 0f && drop) 
		{
			//Makes a duplicate of the coin
			GameObject.Instantiate (Coin, transform.position, Quaternion.identity);
			drop = false;
		}
		//Sets the Sword true if you click the "Attack" key, else sets it false
		if (Input.GetMouseButtonDown (0) == true) 
		{
			Sword.enabled = true;
		} 

		else 
		{
			Sword.enabled = false;
		}
		//Kills division one when its health hits 0
		if (divisionOneHealth <= 0f)
		{
			Destroy (D1);
		}
	}
	//If a collider hits this collider then it checks it was the players sword or the player itself
	void OnTriggerEnter2D (Collider2D other)
	{

		if (other.gameObject.CompareTag ("Player") && hasCollide == false) {
			hasCollide = true;
			//Deals damage to the player or it "Subtracts health from player" causing damage
			GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerHealth -= bossDamage;

			//This creates knockback on the player when it's attacked
			var player = other.GetComponent<PlayerController> ();
			player.knockbackCount = player.knockbackLength;

			if (other.transform.position.x < transform.position.x)
				player.knockedFromRight = true;
			else
				player.knockedFromRight = false;
		}
		else if (other.gameObject.CompareTag ("Sword") && hasCollide == false) {
			hasCollide = true;
			//Deals damage to the boss or it "Subtracts health from boss" causing damage
			bossHealth -= GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerDamage;
			divisionOneHealth -= GameObject.Find ("Player").GetComponent<PlayerHealth> ().playerDamage;
		}
	}
}