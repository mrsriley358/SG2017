﻿using UnityEngine;
using System.Collections;

public class BossDivision : MonoBehaviour 
{
	//Make a reference to the Boss GameObject and health
	public GameObject Boss;
	public BossHealth health;

	public Spawner spawn;
	//A variable to decide if first divide
	public bool firstDivide = true;
		
	void Update() 
	{
		//Continuously check for if the Boss health is 0 or less
		if (health.bossHealth <= 0)
		{
			//Call if the boss is dead
			Death ();
		}
	}

	//This is called if the Boss health is 0 and or its "dead"
	void Death()
	{
		//Destorys the boss object
		Destroy (Boss);

		GameObject.Find ("EnemyManager").GetComponent <Spawner> ().waveCount += 1;

		//Sets false; to allow for the next division to be possible
		firstDivide = false;
	}
}
