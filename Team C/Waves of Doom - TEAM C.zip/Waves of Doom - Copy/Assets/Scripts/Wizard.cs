﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Wizard : MonoBehaviour 
{
	//Game objects to refence the Skeleton,Fireball,Health of the skeleton, and the Player
	public GameObject Skeleton;
	public GameObject fireball;
	public GameObject health;
	public Transform Player;

	//Floats to manage the move speed and range of the skeleton, as well as the health, and patrol range of the skeleton
	public float moveSpeed;
	public float range;
	public float enemyHealth = 15f;
	float enemyMaxHealth = 15;
	float percentHealth = 1f;
	float WizardWait = 2;
	public float wallCheckRadius;
	//Variables to check if the skeleton has hit a wall and is in the same place as the player
	public LayerMask playerLayer;
	public LayerMask isWall;
	public Transform wallCheck;

	//Bools to check whether or not the skeleton is at a wall, in range of the player, and is able to fire a projectile
	public bool wall;
	public bool playerInRange;
	bool moveRight = true;
	bool canFIRE = true;
	bool hasCollide = false;
	//Various variables to get reference to the health text of the skeleton, its animation, and the scaling of its health
	Animator animator;
	public Text enemyHealthText;
	Vector3 theScale;
	Vector2 projectilePOS = new Vector2(0,0);

	void Start () 
	{
		//Gets a reference to the skeletons animator
		animator = GetComponent<Animator> ();
		//Continously starts checking if the skeleton can fire, or attack
		StartCoroutine (Wizattack ());
		//Initalizes theScale
		theScale = transform.localScale;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		//Checking the scene to see if the "wall" has entered range of the skeleton
		wall = Physics2D.OverlapCircle (wallCheck.position, wallCheckRadius, isWall);
		//Sets the spawn of the fireball to be fired infront of the skeleton
		projectilePOS = new Vector2 (Skeleton.transform.position.x+ 0.2f , Skeleton.transform.position.y);
		//Sets the skeletons health to be in a percentage
		percentHealth = enemyHealth / enemyMaxHealth;
		//Displays the health on the healthbar with current Health and Max health: Example XX/XX
		enemyHealthText.text = "Health " + enemyHealth.ToString () + "/" + enemyMaxHealth.ToString ();

//		if (Vector3.Distance (transform.position, Player.position) > range) {
//			flip ();
//		}

		//set the scale of the health bar to what cur_health is
		health.transform.localScale = new Vector2 (percentHealth, 1f);
		hasCollide = false;
		//Checking to see if the player has entered the range of the skeleton
		playerInRange = Physics2D.OverlapCircle (transform.position, range, playerLayer);
		if (playerInRange) {
			//If the player has entered the range of the skeleton then the skeleton changes focus to move at player and begin attacking
			if (Vector3.Distance (transform.position, Player.position) > range) {
				if (!canFIRE && Time.deltaTime == WizardWait) {
					transform.position = Vector3.MoveTowards (transform.position, Player.position, moveSpeed * Time.deltaTime);
					WizardWait += Time.deltaTime;
				}
			}
		} else if (!playerInRange) { 
			//If the player is not in range then continue patrolling the area and flip if you hit a wall
			if (wall) 
				moveRight = !moveRight;
			
			if (moveRight) {
				GetComponent <Rigidbody2D> ().velocity = new Vector2 (moveSpeed, GetComponent <Rigidbody2D> ().velocity.y);
				theScale.x = 1.5f;
				transform.localScale = theScale;
			} else if (!moveRight){
				GetComponent <Rigidbody2D> ().velocity = new Vector2 (-moveSpeed, GetComponent <Rigidbody2D> ().velocity.y);
				theScale.x = -1.5f;
				transform.localScale = theScale;
			}
		}
	}
	//Detects if the sword has hit the skeleton and subtracts health
	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.CompareTag ("Sword") && hasCollide == false) 
		{
			hasCollide = true;
			enemyHealth -= GameObject.Find("Player").GetComponent<PlayerHealth>().playerDamage;
		}
	}

//	void flip()
//	{
//		if (Player.position.x > transform.position.x) {
//			theScale.x = 1.5f;
//			transform.localScale = theScale;
//		} else if (Player.position.x < transform.position.x) {
//			theScale.x = -1.5f;
//			transform.localScale = theScale;
//		}
//	}
	//Plays the animation of the skeleton attack and spawns the fireball
	IEnumerator Wizattack()
	{
		while (true) 
		{
			if (playerInRange && canFIRE) {
				Debug.Log ("aa");
				animator.SetTrigger ("Attack");
				GameObject.Instantiate (fireball, projectilePOS, Quaternion.identity);
				canFIRE = false;
			} else {
				yield return new WaitForSeconds (3);
				canFIRE = true;
			}
		}

	}
	//Displays the skeletons range in scene view
	void OnDrawGizmosSelected()
	{
		Gizmos.DrawSphere (transform.position, range);

	}
}
