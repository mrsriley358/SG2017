﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class RGB : MonoBehaviour 
{
	public Text title;
	public Color lerpColor = Color.red;

	// Use this for initialization
	void Update () 
	{
		title.color = lerpColor = Color.Lerp (Color.red, Color.green, Mathf.PingPong (Time.time * 10, 2));
	}
}
