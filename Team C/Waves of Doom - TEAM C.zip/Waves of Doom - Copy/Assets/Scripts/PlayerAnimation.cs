﻿using UnityEngine;
using System.Collections;

public class PlayerAnimation : MonoBehaviour 
{
	private Animator animator;

	// Use this for initialization
	void Start () 
	{
		animator = GetComponent<Animator> ();
	}
		
	// Update is called once per frame
	void Update () 
	{
		//detects if the key d is pressed
		if (Input.GetKeyDown ("d")) 
		{
			//triggers the player move animation
			animator.SetTrigger ("Move_Player");
		} 

		else if (Input.GetKeyDown ("a")) 
		{
			//triggers the player move animation
			animator.SetTrigger ("Move_Player");
		} 

		else if (Input.GetKeyDown ("space")) 
		{
			//animator.SetTrigger ("Jump_Player");
		}

		//detecting if the mouse left click is pressed(0)
		if (Input.GetMouseButtonDown (0)) 
		{
			//triggers the player attack animation
			animator.SetTrigger ("Attack_Player");
		}
	}
}
