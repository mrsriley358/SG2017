﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour 
{
	
	//Get the two objects for the health system
	public GameObject Player;
	public GameObject health;
	public GameObject Sword;
	public GameObject Shop;

	public int playerDeath;

	//get the current health from the players health bar
	public float maxPlayerHealth = 100;
	public float playerHealth = 100;
	float healthPercent = 1;
	public Text healthText;

	//get the damage wanted to take from enemys
	public float playerDamage = 1f;

	// Update is called once per frame
	void Update ()
	{
		//Sets up the health bar scaling for the player
		healthPercent = playerHealth / maxPlayerHealth;

		//set the scale of the health bar to what cur_health is; therefore, the text sould be set the number as well
		health.transform.localScale = new Vector2 (healthPercent, 1f);
		healthText.text = "Health: " + playerHealth.ToString () + "/" + maxPlayerHealth.ToString ();
	
		//if the players health is 0 or less call death
		if (playerHealth <= 0f) 
		{
			playerHealth = 0f;
			Death ();
		}
		//If you press "f" it will check if you have a health potion and your health is low enough
		if (Input.GetKeyDown ("f")) 
		{
			if (Shop.GetComponent<ShopManager> ().potionCounter > 0 && playerHealth < maxPlayerHealth)
			{
				playerHealth += (maxPlayerHealth * .5f);


				if (playerHealth > maxPlayerHealth)
				{
					playerHealth = maxPlayerHealth;
				}
				PotionUsage ();
			}
		}
	}

	//"kill" the player if this is called
	public void Death()
	{
		playerDeath = 1;
		Destroy (Player);
	}

	void PotionUsage()
	{
		//Gets a reference to the poition counter on the shop game object
		Shop.GetComponent<ShopManager> ().potionCounter -= 1;
		Shop.GetComponent<ShopManager> ().SetPotionCount();
	}

	void Pause() 
	{
		Time.timeScale = 0;
	}
}