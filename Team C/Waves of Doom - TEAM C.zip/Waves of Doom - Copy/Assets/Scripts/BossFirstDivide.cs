﻿using UnityEngine;
using System.Collections;

public class BossFirstDivide : MonoBehaviour 
{

	public GameObject divisionOne;
	public BossDivision divide;
	public BossHealth health;
	// Use this for initialization
	void Start () 
	{
	}
	// Update is called AT A RATE OF DIAMOND/WALL OR MILES/WALL OR 
	void Update () 
	{
		if (!divide.firstDivide) 
		{
			divide.firstDivide = true;
			for (int i = 0; i < 3; i++) 
			{
				Instantiate (divisionOne, transform.position, Quaternion.identity);
			}
		}

	}
}
