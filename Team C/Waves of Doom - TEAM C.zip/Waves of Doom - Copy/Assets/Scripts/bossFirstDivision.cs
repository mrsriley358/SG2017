﻿using UnityEngine;
using System.Collections;

public class BossFirstDivision : MonoBehaviour 
{
	public GameObject divisionOne;
	public BossDivision divide;
	public BossHealth health;
	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (divide.firstDivide == true) 
		{
			
			divide.firstDivide = false;

			for (int i = 0; i < 3; i++) 
			{
				Instantiate (divisionOne, transform.position, Quaternion.identity);
			}
		}
		if (health.divisionOneHealth <= 0f)
		{
			Destroy (divisionOne);
		}
	}
}
