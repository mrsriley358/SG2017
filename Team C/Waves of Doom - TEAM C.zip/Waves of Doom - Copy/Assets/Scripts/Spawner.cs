﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Spawner : MonoBehaviour 
{
	//Integer variables used for enemy and wave counters, and time references
	public int waveCount;
	int Bosswave;
	public float SpawnTime = 3f;
	public int spawnDelay = 1;
	int spawnAmount = 5;
	public int EC;
	//Text for holding how many enemies are in the game.
	public Text enemiesRemaining;
	public Text waveNumber;

	//Enemy references
	public GameObject Enemy;
	public GameObject EnemySkel;
	GameObject[] enemyCounter;
	public GameObject boss;

	//Places to hold the Location Values
	private Vector2 SpawnPosition;

	void FixedUpdate()
	{
		if (waveCount == 10)
			spawnAmount = 1;
		waveNumber.text = "Wave " + waveCount.ToString ();
		enemyCounter = GameObject.FindGameObjectsWithTag("Enemy");
		EC = enemyCounter.Length;

		enemiesRemaining.text = ("Enemies Remaining: " + EC);

		if (enemyCounter.Length < 4 && enemyCounter.Length == 0f)
		{
			Spawn ();
		}
	}
		
	void Spawn () 
	{
		if (waveCount == 11)
			SceneManager.LoadScene ("VictoryScreen");
		if (Bosswave < 10) {
			//Decides if Spawn amount is greater than 0 and the position is false
			if (waveCount < 10) {
				//Adds a random number to the previous spawn amount
				spawnAmount += Random.Range (1, 5);
				//Starts the spawning of enemies
				if (EC == 0) {
					//Adds a value of 1 to the wave count and boss waves
					waveCount++;
					Bosswave++;
				StartCoroutine (SpawnEnemy ());



				}
			}
		}
	}

	void Change()
	{
		//Changes the spawn position of the enemies to be random on the X-axis
		SpawnPosition = new Vector2 (Random.Range(-12.5f, 12.5f), 1f);
	}

	IEnumerator SpawnEnemy ()
	{

		//Creates enemies for an X amount
		for (int i = 0; i < spawnAmount; i++) {
			if (waveCount < 10) {
				//Calls the change method to get a new random spawn location
				Change ();
				int spawnType = Random.Range (2, 6);
				//If the random int hits 1 it will spawn a skeleton
				if (spawnType == 1)
					GameObject.Instantiate (EnemySkel, SpawnPosition, Quaternion.identity);
				// If the random int hits anything other than 1, it will spawn bats
				else
					GameObject.Instantiate (Enemy, SpawnPosition, Quaternion.identity);
			} else if (waveCount == 10) {
				GameObject.Instantiate (boss, SpawnPosition, Quaternion.identity);
			}
			//Wait X amount of time before repeating this spawn
			yield return new WaitForSeconds (spawnDelay);
		} 
	}
}