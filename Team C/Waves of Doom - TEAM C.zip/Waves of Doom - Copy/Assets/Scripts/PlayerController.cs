﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour 
{
	//sets the speed of the player
	public float maxSpeed = 5f;
	public Rigidbody2D rb2d;
	public int Health;
	//variables to check if on the ground
	public Transform groundCheck;
	public float groundCheckRadius;
	public LayerMask isGround;
	//vectors for the position of mouse and player
	Vector2 mousePos;
	Vector2 charPos;
	//Used for if the player has already double jumped
	bool doubleJump;
	//The amount of force givin for jumping
	public float jHeight = 400f;
	//Variables for the knockback
	public float knockback, knockbackLength, knockbackCount;
	public bool knockedFromRight;
	float move;
	//Check if the player is on the ground
	bool grounded;
	bool FacingRight = true;

	// Use this for initialization
	void Start ()
	{
		//Sets the player health to 100 at the start, and grabs the rigidbody of the object attached to this script
		Health = 100;
		rb2d = GetComponent<Rigidbody2D> ();
	}

	void Update ()
	{
		//Continuously finds where the mouses position is and the characters position
		mousePos = new Vector2 (Input.mousePosition.x, Screen.height - Input.mousePosition.y);
		charPos = Camera.main.WorldToScreenPoint (transform.position);
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		//Sets the bool true or false based if you are on the ground
		grounded = Physics2D.OverlapCircle (groundCheck.position, groundCheckRadius, isGround);
		move = Input.GetAxis ("Horizontal");
		//If you are grounded it sets your doublejump to false
		if (grounded == true)
			doubleJump = false;
		//Checks if you are taking knock-back or not
		if (knockbackCount <= 0) 
		{
			//Checks where your mouse is realtive to the players position, and flips you accordingly
			if (charPos.x > mousePos.x) 
			{
				Move ();
				if (FacingRight)
				{
					Flip ();
					FacingRight = false;
				}
			}

			else if (charPos.x < mousePos.x) 
			{
				Move ();
				if (!FacingRight)
				{
					Flip ();
					FacingRight = true;
				}
			} 
		} 

		else 
		{
			//If you are Knocked back it checks if you are on the right or left side of the object you took damage from
			if (knockedFromRight) 
			{
				rb2d.velocity = new Vector2 (-knockback, knockback);
			}
			
			else if (!knockedFromRight)
			{
				rb2d.velocity = new Vector2 (knockback, knockback); 
			}
			
			knockbackCount -= Time.deltaTime;
		}
	}
	//Flips the player based on where your mouse is
	void Flip() 
	{
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}
	//This script allows you to move and jump, also allows for a double jump
	void Move()
	{
		
		if (Input.GetKey ("a") && Input.GetKeyDown ("space") && grounded || Input.GetKey ("d") && Input.GetKeyDown ("space") && grounded) 
		{
			rb2d.velocity = new Vector2 (move * maxSpeed, rb2d.velocity.y);
			rb2d.AddForce (Vector2.up * jHeight);
		}
		else if (Input.GetKey ("a") && Input.GetKeyDown ("space") && !doubleJump || Input.GetKey ("d") && Input.GetKeyDown ("space") && !doubleJump) 
		{
			rb2d.AddForce (Vector2.up * jHeight);
			doubleJump = true;
		}
		else if (Input.GetKeyDown ("space") && grounded) 
		{
			rb2d.AddForce (Vector2.up * jHeight);
		} 
		else if (Input.GetKey ("a") || Input.GetKey ("d")) 
		{	
			rb2d.velocity = new Vector2 (move * maxSpeed, rb2d.velocity.y);
		}
		else if (Input.GetKeyDown ("space") && !doubleJump) 
		{
			rb2d.AddForce (Vector2.up * jHeight);
			doubleJump = true;
		}
		else 
		{
			rb2d.velocity = new Vector2 (0f, rb2d.velocity.y);
		}
	}
}