﻿using UnityEngine;
using System.Collections;


public class Respawn : MonoBehaviour 
{
	//Variables to reference the player and boss
	public GameObject Player;
	public GameObject Boss;
	//detects if the boss or player has fallen through a collider
	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "Player") 
		{
			//Repositions the player back into the level
			Player.transform.position = new Vector2 (0, -2);
		} 
		else if (other.tag == "Boss") 
		{
			//Destroys the boss that has fallen
			DestroyObject (Boss);
		}
	}
}




