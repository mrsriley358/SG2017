﻿using UnityEngine;
using System.Collections;

public class EnemyMovement : MonoBehaviour 
{
	//Gets the targets position, or PLayer in this case 
	public Transform target;
	//Make a variable speed to use later, also gets the rigidbody of the object that the script is attacted to
	public float speed;
	public Rigidbody2D enemy;

	void Start () 
	{
		//Gets the "targets" position
		target = GameObject.FindWithTag ("Player").transform;
		enemy = GetComponent<Rigidbody2D> ();
	}

	void FixedUpdate()
	{
		//constantly calls the attack method
			Attack ();
	}

	void Attack()
	{
		//has the enemy hone in on the player
		transform.position = Vector3.MoveTowards (transform.position, target.position, speed * Time.deltaTime);
	}
}