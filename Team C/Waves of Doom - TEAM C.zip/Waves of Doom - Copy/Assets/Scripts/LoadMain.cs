﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoadMain : MonoBehaviour 
{
	//Loads main scene
	public void NewGame ()
	{

		SceneManager.LoadScene ("Main");

		GameObject.Find ("PotionAmount").SetActive (true);

	}
	//Quits game
	public void ExitGame ()
	{

		Application.Quit ();

	}
	//Loads options menu
	public void Load ()
	{

		SceneManager.LoadScene ("OptionsMenu");

	}
	//Opens the start menu
	public void ExitOptionsMenu ()
	{

		SceneManager.LoadScene ("StartMenu");

	}
	//Exits the game and loads startmenu
	public void Exit ()
	{

		Time.timeScale = 1;
		SceneManager.LoadScene ("StartMenu");

	}
}
