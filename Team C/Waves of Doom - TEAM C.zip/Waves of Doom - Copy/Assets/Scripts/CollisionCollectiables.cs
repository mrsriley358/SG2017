﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CollisionCollectiables : MonoBehaviour 
{
	// Creates integers for a money system
	public int gold;
	public int goldPerWave;
	//Creating a reference variable to the "Text" and "Coin" objects ingame
	public Text ScoreText;
	public GameObject Coin;

	void Start () 
	{
		//Calls SetScoreText every time a coin spawns
		SetScoreText ();
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		// If player collides with currency adds to score and sets the coin to be destroyed
		if (other.gameObject.CompareTag ("Currency")) 
		{
			Destroy(other.gameObject);
			gold += goldPerWave;
			SetScoreText ();
		}
	}

	public void SetScoreText()
	{
		//Convert the counter value on collision to a value displayed ingame
		ScoreText.text = "Gold: " + gold.ToString();
	}
}
