﻿using UnityEngine;
using System.Collections;

public class PlayersDeath : MonoBehaviour 
{
	//Variables to reference the Death screen and players health
	public GameObject deathScreen;

	public PlayerHealth death;
	
	// Update is called once per frame
	void Update () 
	{
		//Calls RestartScreen
		RestartScreen ();
	}

	public void RestartScreen ()
	{
		//Determines if the player is dead
		if (death.playerDeath == 1) 
			{
				//Calls Pause
				Pause ();
				//Sets the death screen to be visable
				deathScreen.SetActive (true);
				//Gets a reference to the potion amount and sets it false
				GameObject.Find ("PotionAmount").SetActive (false);
				//Sets player death to be 0 so it only runs this once
				death.playerDeath = 0;
			}
	}

	void Pause() 
	{
		//Pauses the time ingame so it doesnt keep going
		Time.timeScale = 0;
	}
}
