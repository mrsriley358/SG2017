﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour 
{
	//Get the two objects for the health system
	public GameObject Enemy;
	public GameObject health;
	//get the current health from the enemys health bar
	public float enemyHealth = 15f;
	public float enemyDamage = 10f;
	float enemyMaxHealth = 15;
	float percentHealth = 1f;

	public Text enemyHealthText;

	private bool hasCollide = false;
	private CircleCollider2D Sword;

	int wave;
	int oldWave;

	public GameObject Coin;

	int Number = 0;

	// Update is called once per frame
	void Update () 
	{
		//Sets boss health scaling
		percentHealth = enemyHealth / enemyMaxHealth;
		//Displays health over maxhealth
		enemyHealthText.text = "Health " + enemyHealth.ToString () + "/" + enemyMaxHealth.ToString ();

		//set the scale of the health bar to what cur_health is
		health.transform.localScale = new Vector2 (percentHealth, 1f);

		//Finds and sets the value of waveCount from the EnemyManager script to variable wave
		wave = GameObject.Find ("EnemyManager").GetComponent <Spawner> ().waveCount;
		//Allows the bats to gain health every wave
		if (oldWave != wave) 
		{
			enemyHealth += 5;
			enemyMaxHealth += 5;

			oldWave++;
		}

		hasCollide = false;

		Sword = GameObject.Find ("Sword").GetComponent<CircleCollider2D> ();
		//If the enemy bat dies it has a chance to spawn a duplicate of the coin
		if (enemyHealth <= 0f) 
		{
			Number = Death (Number);

			if (Number == 1) 
			{
				GameObject.Instantiate (Coin, transform.position, Quaternion.identity);
			}
		}
		//Sets the Sword true if you click the "Attack" key, else sets it false
		if (Input.GetMouseButtonDown (0) == true) 
		{
			Sword.enabled = true;
		} 

		else 
		{
			Sword.enabled = false;
		}
	}
	//If a collider hits this collider then it checks it was the players sword or the player itself
	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.CompareTag ("Player") && hasCollide == false) 
		{
			hasCollide = true;
			//Deals damage to the player or it "Subtracts health from player" causing damage
			GameObject.Find ("Player").GetComponent<PlayerController> ().knockbackCount = .2f;
			GameObject.Find("Player").GetComponent<PlayerHealth>().playerHealth -= enemyDamage;
			//This creates knockback on the player when it's attacked
			var player = other.GetComponent <PlayerController> ();
			player.knockbackCount = player.knockbackLength;

				if (other.transform.position.x < transform.position.x)
				{
					player.knockedFromRight = true;
				}
					
				else
				{
					player.knockedFromRight = false;
				}
		}

		if (other.gameObject.CompareTag ("Sword") && hasCollide == false) 
		{
			hasCollide = true;
			//Deals damage to the bat or it "Subtracts health from bat" causing damage
			enemyHealth -= GameObject.Find("Player").GetComponent<PlayerHealth>().playerDamage;
		}
	}

	//"kill" the enemy if this is called
	public int Death(int Number)
	{
		Destroy (Enemy);
		//Returns a random number 0, or 1
		Number = Random.Range (0, 2);
		return Number;
	}


}
